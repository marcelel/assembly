//---------------------------------------------------------------
// Test program - grupa D
//---------------------------------------------------------------

#include <stdlib.h>
#include <stdio.h>

char* encode(char* buf, unsigned int mask, int operation, int character);
 
int main(){
    char buf1[] = "#aAa_0123456789aBc!;";
    char buf2[] = "#aAa_0123456789aBc!;";
    char buf3[] = "#aAa_0123456789aBc!;";
    char buf4[] = "#aAa_0123456789aBc!;";
    char buf5[] = "#aAa_0123456789aBc!;";
    char buf6[] = "#aAa_0123456789aBc!;";

    printf("Original: %s\n", buf1 );
    printf("After_1 : %s\n", encode( buf1, 0x30F, 0, '@' ) );
    printf("After_2 : %s\n", encode( buf2, 0x30F, 1, '@' ) );
    printf("After_3 : %s\n", encode( buf3, 0x30F, 2, '@' ) );
    printf("After_4 : %s\n", encode( buf4, 0x30F, 3, '@' ) );
    printf("After_5 : %s\n", encode( buf5, 0x30F, 4, '@' ) );
    printf("After_6 : %s\n", encode( buf6, 0x3FF, 1, '@' ) );
    return 0;
}

